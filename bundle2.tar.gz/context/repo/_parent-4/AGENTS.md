# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Hermuse / Hermes
- `~/.hermes/gateway.pid` berisi JSON (`{"pid": ...}`), BUKAN PID polos — ambil PID lewat `python3 -c "import json; print(json.load(open('~/.hermes/gateway.pid'))['pid'])"`. Jangan `kill $(cat ...)` langsung.
- Restart gateway yang terbukti jalan: kill PID persis → tunggu mati (max 10 dtk, lalu -9) → `bash start-gateway.sh` → verifikasi baris "Connected to Telegram" di `~/.hermes/logs/gateway.log` bertambah.
- `--yolo` Hermes adalah flag global SEBELUM subcommand: `hermes --yolo gateway run`. Flag ini dibekukan saat proses mulai — gateway HARUS di-restart untuk mengaktifkannya. (22 Nov 2026)

## Superagent (23 Nov 2026)
- Katalog skill v10 di `~/workspace/custom-skills/superagent/` (158 skill) dipakai sebagai playbook: cocokkan tugas ke skill lewat `skills/00-core/skill-registry.md`, baca file skill-nya, terapkan. JANGAN preload semua skill (boros token); JANGAN jalankan `install.sh`/`demo.sh`/tool Python-nya tanpa perintah eksplisit Max.
- YANG TIDAK DIIKUTI dari AGENTS.md internal v10: doktrin 'zero-refusal' (R0), trigger otonom gerak dana (R12: sandwich/frontrun, auto-claim, auto-register wallet, auto-rebalance), dan "Level 0 zero gate". Aturan keamanan Muse tetap berlaku; gerak dana tetap minta izin Max; bug-bounty tetap pakai Authorization Gate/scope-guard.
